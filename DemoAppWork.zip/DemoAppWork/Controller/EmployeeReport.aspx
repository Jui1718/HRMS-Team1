﻿<%@ Page Language="C#" AutoEventWireup="true" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>Employee Report</title>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />

    <!-- Tabler Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@latest/tabler-icons.min.css" />

    <!-- DataTables CSS -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css" />

    <style>
        body {
            background-color: #f6f7fb;
            font-family: Arial, sans-serif;
        }

        .page-wrapper {
            padding: 24px;
        }

        .page-breadcrumb h2 {
            font-size: 24px;
            font-weight: 600;
        }

        .breadcrumb-item a {
            color: #6c757d;
            text-decoration: none;
        }

        .card {
            border: 1px solid #e9e9e9;
            border-radius: 8px;
            box-shadow: 0 1px 2px rgba(0,0,0,0.03);
        }

        .card-body {
            padding: 20px;
        }

        .card-header {
            background: #fff;
            border-bottom: 1px solid #eee;
            padding: 18px 20px;
        }

        .text-gray-1 {
            color: #777;
        }

        .badge-xs {
            padding: 5px 8px;
            font-size: 12px;
        }

        .badge-success {
            background-color: #e8f8ef;
            color: #28a745;
        }

        .badge-danger {
            background-color: #fdecec;
            color: #dc3545;
        }

        .table thead th {
            background-color: #f8f9fa;
            font-weight: 600;
            white-space: nowrap;
        }

        .table td {
            vertical-align: middle;
            white-space: nowrap;
        }

        .employee-img {
            width: 40px;
            height: 40px;
            object-fit: cover;
        }

        .export-btn {
            border: 1px solid #dee2e6;
            background: #fff;
        }

        .stat-icon {
            width: 45px;
            height: 45px;
            object-fit: contain;
        }

        .chart-container {
            height: 280px;
        }

        .form-select-sm {
            min-width: 150px;
        }
    </style>
</head>

<body>

<form id="form1" runat="server">

    <div class="page-wrapper">

        <!-- Breadcrumb -->
        <div class="d-md-flex d-block align-items-center justify-content-between page-breadcrumb mb-3">

            <div class="my-auto mb-2">

                <h2 class="mb-1">Employee Report</h2>

                <nav>
                    <ol class="breadcrumb mb-0">

                        <li class="breadcrumb-item">
                            <a href="#">
                                <i class="ti ti-smart-home"></i>
                            </a>
                        </li>

                        <li class="breadcrumb-item">
                            HR
                        </li>

                        <li class="breadcrumb-item active" aria-current="page">
                            Employee Report
                        </li>

                    </ol>
                </nav>

            </div>

            <div class="d-flex my-xl-auto right-content align-items-center flex-wrap">

                <div class="mb-2">

                    <div class="dropdown">

                        <a href="javascript:void(0);"
                           class="dropdown-toggle btn btn-white d-inline-flex align-items-center export-btn"
                           data-bs-toggle="dropdown">

                            <i class="ti ti-file-export me-1"></i>
                            Export

                        </a>

                        <ul class="dropdown-menu dropdown-menu-end p-3">

                            <li>
                                <a href="#" class="dropdown-item rounded-1">
                                    <i class="ti ti-file-type-pdf me-1"></i>
                                    Export as PDF
                                </a>
                            </li>

                            <li>
                                <a href="#" class="dropdown-item rounded-1">
                                    <i class="ti ti-file-type-xls me-1"></i>
                                    Export as Excel
                                </a>
                            </li>

                        </ul>

                    </div>

                </div>

                <div class="head-icons ms-2">

                    <a href="javascript:void(0);"
                       data-bs-toggle="tooltip"
                       data-bs-placement="top"
                       title="Collapse">

                        <i class="ti ti-chevrons-up"></i>

                    </a>

                </div>

            </div>

        </div>
        <!-- /Breadcrumb -->


        <!-- Statistics + Chart -->
        <div class="row">

            <!-- Left Statistics -->
            <div class="col-xl-6 d-flex">

                <div class="row flex-fill">

                    <!-- Total Employee -->
                    <div class="col-lg-6 col-md-6 d-flex">

                        <div class="card flex-fill">

                            <div class="card-body">

                                <div class="overflow-hidden d-flex mb-2 align-items-center">

                                    <span class="me-2">
                                        <img src="/assets/img/reports-img/employee-report-icon.svg"
                                             alt="Img"
                                             class="img-fluid stat-icon" />
                                    </span>

                                    <div>

                                        <p class="fs-14 fw-normal mb-1 text-truncate">
                                            Total Employee
                                        </p>

                                        <h5>120</h5>

                                    </div>

                                </div>

                                <div>

                                    <p class="fs-12 fw-normal d-flex align-items-center text-truncate">

                                        <span class="text-success fs-12 d-flex align-items-center me-1">

                                            <i class="ti ti-arrow-wave-right-up me-1"></i>
                                            +20.01%

                                        </span>

                                        from last week

                                    </p>

                                </div>

                            </div>

                        </div>

                    </div>
                    <!-- /Total Employee -->


                    <!-- Total Department -->
                    <div class="col-lg-6 col-md-6 d-flex">

                        <div class="card flex-fill">

                            <div class="card-body">

                                <div class="overflow-hidden d-flex mb-2 align-items-center">

                                    <span class="me-2">

                                        <img src="/assets/img/reports-img/employee-report-success.svg"
                                             alt="Img"
                                             class="img-fluid stat-icon" />

                                    </span>

                                    <div>

                                        <p class="fs-14 fw-normal mb-1 text-truncate">
                                            Total Department
                                        </p>

                                        <h5>8</h5>

                                    </div>

                                </div>

                                <div>

                                    <p class="fs-12 fw-normal d-flex align-items-center text-truncate">

                                        <span class="text-success fs-12 d-flex align-items-center me-1">

                                            <i class="ti ti-arrow-wave-right-up me-1"></i>
                                            +20.01%

                                        </span>

                                        from last week

                                    </p>

                                </div>

                            </div>

                        </div>

                    </div>
                    <!-- /Total Department -->


                    <!-- Active Employee -->
                    <div class="col-lg-6 col-md-6 d-flex">

                        <div class="card flex-fill">

                            <div class="card-body">

                                <div class="overflow-hidden d-flex mb-2 align-items-center">

                                    <span class="me-2">

                                        <img src="/assets/img/reports-img/employee-report-info.svg"
                                             alt="Img"
                                             class="img-fluid stat-icon" />

                                    </span>

                                    <div>

                                        <p class="fs-14 fw-normal mb-1 text-truncate">
                                            Active Employee
                                        </p>

                                        <h5>95</h5>

                                    </div>

                                </div>

                                <div>

                                    <p class="fs-12 fw-normal d-flex align-items-center text-truncate">

                                        <span class="text-success fs-12 d-flex align-items-center me-1">

                                            <i class="ti ti-arrow-wave-right-up me-1"></i>
                                            +20.01%

                                        </span>

                                        from last week

                                    </p>

                                </div>

                            </div>

                        </div>

                    </div>
                    <!-- /Active Employee -->


                    <!-- Roles -->
                    <div class="col-lg-6 col-md-6 d-flex">

                        <div class="card flex-fill">

                            <div class="card-body">

                                <div class="overflow-hidden d-flex mb-2 align-items-center">

                                    <span class="me-2">

                                        <img src="/assets/img/reports-img/employee-report-danger.svg"
                                             alt="Img"
                                             class="img-fluid stat-icon" />

                                    </span>

                                    <div>

                                        <p class="fs-14 fw-normal mb-1 text-truncate">
                                            Roles
                                        </p>

                                        <h5>12</h5>

                                    </div>

                                </div>

                                <div>

                                    <p class="fs-12 fw-normal d-flex align-items-center text-truncate">

                                        <span class="text-success fs-12 d-flex align-items-center me-1">

                                            <i class="ti ti-arrow-wave-right-up me-1"></i>
                                            +20.01%

                                        </span>

                                        from last week

                                    </p>

                                </div>

                            </div>

                        </div>

                    </div>
                    <!-- /Roles -->

                </div>

            </div>


            <!-- Employee Chart -->
            <div class="col-xl-6 d-flex">

                <div class="card flex-fill">

                    <div class="card-header border-0 pb-0">

                        <div class="d-flex flex-wrap justify-content-between align-items-center row-gap-2">

                            <div class="d-flex align-items-center">

                                <span class="me-2">
                                    <i class="ti ti-chart-bar text-danger"></i>
                                </span>

                                <h5 class="mb-0">
                                    Employee
                                </h5>

                            </div>


                            <div class="d-flex align-items-center">

                                <p class="d-inline-flex align-items-center me-3 mb-0">

                                    <i class="ti ti-square-filled fs-12 text-success me-2"></i>

                                    Active Employees

                                </p>

                                <p class="d-inline-flex align-items-center mb-0">

                                    <i class="ti ti-square-filled fs-12 text-gray-1 me-2"></i>

                                    Inactive Employees

                                </p>

                            </div>


                            <div class="dropdown">

                                <a href="javascript:void(0);"
                                   class="dropdown-toggle btn btn-sm fs-12 btn-white d-inline-flex align-items-center"
                                   data-bs-toggle="dropdown">

                                    This Year

                                </a>

                                <ul class="dropdown-menu dropdown-menu-end p-2">

                                    <li>
                                        <a href="#" class="dropdown-item rounded-1">
                                            2024
                                        </a>
                                    </li>

                                    <li>
                                        <a href="#" class="dropdown-item rounded-1">
                                            2023
                                        </a>
                                    </li>

                                    <li>
                                        <a href="#" class="dropdown-item rounded-1">
                                            2022
                                        </a>
                                    </li>

                                </ul>

                            </div>

                        </div>

                    </div>


                    <div class="card-body py-0">

                        <div class="chart-container">

                            <canvas id="barChart"></canvas>

                        </div>

                    </div>

                </div>

            </div>

        </div>
        <!-- /Statistics + Chart -->


        <!-- Employees List Header -->
        <div class="card mt-3">

            <div class="card-header d-flex align-items-center justify-content-between flex-wrap row-gap-3">

                <h5 class="mb-0">
                    Employees List
                </h5>

                <div class="d-flex my-xl-auto right-content align-items-center flex-wrap row-gap-3">

                    <div class="dropdown me-3">

                        <select class="form-select form-select-sm"
                                id="statusFilter"
                                onchange="sortTable();">

                            <option value="active">
                                Active
                            </option>

                            <option value="inactive">
                                Inactive
                            </option>

                        </select>

                    </div>


                    <div class="dropdown">

                        <select class="form-select form-select-sm"
                                id="sortFilter"
                                onchange="sortTable();">

                            <option value="recent">
                                Recently Added
                            </option>

                            <option value="asc">
                                Ascending
                            </option>

                            <option value="desc">
                                Descending
                            </option>

                            <option value="lastMonth">
                                Last Month
                            </option>

                            <option value="last7Days">
                                Last 7 Days
                            </option>

                        </select>

                    </div>

                </div>

            </div>

        </div>
        <!-- /Employees List Header -->


        <!-- Employees Table -->
        <div class="card-body p-0">

            <div class="custom-datatable-filter table-responsive">

                <table class="table" id="EmpTableId">

                    <thead class="thead-light">

                        <tr>

                            <th>UserId</th>

                            <th>Name</th>

                            <th>Email</th>

                            <th>Department</th>

                            <th>PhoneNumber</th>

                            <th>Date of Joining</th>

                            <th>Status</th>

                        </tr>

                    </thead>


                    <tbody>

                        <tr>

                            <td>101</td>

                            <td>

                                <div class="d-flex align-items-center">

                                    <img src="/assets/img/profiles/avatar-01.jpg"
                                         alt="Profile"
                                         class="rounded-circle employee-img" />

                                    <div class="ms-2">

                                        <strong>John Smith</strong>

                                    </div>

                                </div>

                            </td>

                            <td>john.smith@gmail.com</td>

                            <td>IT</td>

                            <td>9876543210</td>

                            <td>15/01/2024</td>

                            <td>

                                <span class="badge badge-success d-inline-flex align-items-center badge-xs">

                                    <i class="ti ti-point-filled me-1"></i>

                                    Active

                                </span>

                            </td>

                        </tr>


                        <tr>

                            <td>102</td>

                            <td>

                                <div class="d-flex align-items-center">

                                    <img src="/assets/img/profiles/avatar-02.jpg"
                                         alt="Profile"
                                         class="rounded-circle employee-img" />

                                    <div class="ms-2">

                                        <strong>Sarah Wilson</strong>

                                    </div>

                                </div>

                            </td>

                            <td>sarah.wilson@gmail.com</td>

                            <td>HR</td>

                            <td>9876543211</td>

                            <td>20/02/2024</td>

                            <td>

                                <span class="badge badge-success d-inline-flex align-items-center badge-xs">

                                    <i class="ti ti-point-filled me-1"></i>

                                    Active

                                </span>

                            </td>

                        </tr>


                        <tr>

                            <td>103</td>

                            <td>

                                <div class="d-flex align-items-center">

                                    <img src="/assets/img/profiles/avatar-03.jpg"
                                         alt="Profile"
                                         class="rounded-circle employee-img" />

                                    <div class="ms-2">

                                        <strong>Michael Brown</strong>

                                    </div>

                                </div>

                            </td>

                            <td>michael.brown@gmail.com</td>

                            <td>Finance</td>

                            <td>9876543212</td>

                            <td>10/03/2024</td>

                            <td>

                                <span class="badge badge-danger d-inline-flex align-items-center badge-xs">

                                    <i class="ti ti-point-filled me-1"></i>

                                    Deactive

                                </span>

                            </td>

                        </tr>


                        <tr>

                            <td>104</td>

                            <td>

                                <div class="d-flex align-items-center">

                                    <img src="/assets/img/profiles/avatar-04.jpg"
                                         alt="Profile"
                                         class="rounded-circle employee-img" />

                                    <div class="ms-2">

                                        <strong>David Miller</strong>

                                    </div>

                                </div>

                            </td>

                            <td>david.miller@gmail.com</td>

                            <td>Marketing</td>

                            <td>9876543213</td>

                            <td>05/04/2024</td>

                            <td>

                                <span class="badge badge-success d-inline-flex align-items-center badge-xs">

                                    <i class="ti ti-point-filled me-1"></i>

                                    Active

                                </span>

                            </td>

                        </tr>


                    </tbody>

                </table>

            </div>

        </div>
        <!-- /Employees Table -->

    </div>

</form>


<!-- jQuery -->
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<!-- Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<!-- DataTables -->
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>


<script>

    // Employee Chart
    const ctx = document.getElementById('barChart').getContext('2d');

    const barChart = new Chart(ctx, {

        type: 'bar',

        data: {

            labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
                'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],

            datasets: [

                {
                    label: 'Active Users',

                    data: [45, 55, 60, 65, 70, 75,
                        80, 85, 90, 92, 95, 100],

                    backgroundColor: 'rgba(75, 192, 75, 0.6)',

                    borderColor: 'rgba(75, 192, 75, 1)',

                    borderWidth: 1
                },

                {
                    label: 'Inactive Users',

                    data: [20, 25, 22, 28, 30, 25,
                        32, 27, 30, 25, 28, 20],

                    backgroundColor: 'rgba(128, 128, 128, 0.6)',

                    borderColor: 'rgba(128, 128, 128, 1)',

                    borderWidth: 1
                }

            ]

        },

        options: {

            responsive: true,

            plugins: {

                legend: {
                    display: false
                }

            },

            scales: {

                x: {
                    stacked: false
                },

                y: {

                    beginAtZero: true,

                    ticks: {
                        stepSize: 10
                    }

                }

            }

        }

    });


    // DataTable
    $(document).ready(function () {

        $('#EmpTableId').DataTable({

            paging: true,

            searching: true,

            ordering: true,

            info: true,

            pageLength: 10

        });

    });


    // Sorting
    function sortTable() {

        const sortValue =
            document.getElementById("sortFilter").value;

        const table =
            document.getElementById("EmpTableId");

        const rows =
            Array.from(
                table.getElementsByTagName("tr")
            ).slice(1);


        rows.sort(function (rowA, rowB) {

            const cellA =
                rowA.getElementsByTagName("td")[1].textContent.trim();

            const cellB =
                rowB.getElementsByTagName("td")[1].textContent.trim();


            switch (sortValue) {

                case "asc":

                    return cellA.localeCompare(cellB);


                case "desc":

                    return cellB.localeCompare(cellA);


                default:

                    return 0;

            }

        });


        rows.forEach(function (row) {

            table
                .getElementsByTagName("tbody")[0]
                .appendChild(row);

        });

    }

</script>

</body>
</html>